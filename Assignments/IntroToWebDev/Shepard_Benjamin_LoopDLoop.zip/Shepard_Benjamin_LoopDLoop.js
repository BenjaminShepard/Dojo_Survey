// We need a loop in this instance because the same logic happens more than once
// the starting point of this loop mile 0
// the loop stops the last time the runner gets candy, so in this instance at mile 6
// The increments for this loop is how many miles the runner has run
// The variables are how many miles the runner has ran
for(var mile = 0; mile <=6; mile++){
    if (mile % 2 === 0 && mile !=0){
        console.log("Here's your candy!", `Mile: ${mile}`)
    }
}