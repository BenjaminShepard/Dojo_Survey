var riderHeight = 42 
// 42 is the riders height in inches

var riderAge = 10 
// 10 is the riders age in years
