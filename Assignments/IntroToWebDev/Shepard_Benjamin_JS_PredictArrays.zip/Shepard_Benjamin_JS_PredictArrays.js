//code snippet 1
var contactInfo = ["Paula", "Smith", "1234 Main Street", "St. Louis", "MO", 12345];
console.log(contactInfo);

// line 2 creates a variable calld contactInfe with the information ["Paula", "Smith", "1234 Main Street", "St. Louis", "MO", 12345]; stored
// line 3 is a console log that will print ["Paula", "Smith", "1234 Main Street", "St. Louis", "MO", 12345];

//code snippet 2
var produce = ["apples", "oranges"];
var frozen = ["broccoli", "ice cream"];
frozen.push("hashbrowns");
console.log(frozen);

// line 8 is a variable called produce with the information ["apples", "oranges"]; stored inside
// line 9 is another variable called frozen with the information ["broccoli", "ice cream"]; stored inside it
// line 10 is a push command that is inserting "hashbrowns" into the variable frozen. "hashbrowns" will be inserted at teh end of ["broccoli", "ice cream"] since push commands will always insert at the end
// line 11 is a console log that will print the updated frozen variable ["broccoli", "ice cream""hashbrowns"]

//code snippet 3
var movieLibrary = ["Bambi", "E.T.", "Toy Story"];
movieLibrary.push("Zorro");
movieLibrary[1] = "Beetlejuice";
console.log(movieLibrary);

// line 20 is a variable called movieLibrary that stores the information ["Bambi", "E.T.", "Toy Story"];
// line21 is a push command inserting "Zorro" into the movieLibrary variable
// line 22 is a command inserting "Beeteljuice" into the first position of the array resulting in ["Bambi", "Beetlejuice", "Toy Story"];
// line 23 is a console log that will print ["Bambi", "Beetlejuice", "Toy Story"];